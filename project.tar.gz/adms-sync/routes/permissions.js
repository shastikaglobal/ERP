const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

// profiles and user_permissions live in Supabase, with fallbacks to local VPS DB

// GET /api/user-permissions?user_id=xxx  OR  GET /api/user-permissions (admin matrix)
router.get('/', requireAuth, async (req, res) => {
  try {
    const { user_id } = req.query;

    if (user_id) {
      // Single user — return their permissions array
      try {
        const { rows } = await db.query(
          'SELECT section, has_access FROM user_permissions WHERE user_id = $1',
          [user_id]
        );
        return res.json(rows);
      } catch (dbErr) {
        console.error('[API /user-permissions] Local query failed:', dbErr.message);
        throw dbErr;
      }
    }

    // All users + their permissions (for admin matrix view)
    let profiles = [];
    let perms = [];

    try {
      const { rows: localProfiles } = await db.query(
        "SELECT id, full_name, email, requested_role FROM profiles WHERE deleted_at IS NULL ORDER BY full_name"
      );
      const { rows: localPerms } = await db.query(
        "SELECT user_id, section, has_access FROM user_permissions"
      );
      profiles = localProfiles;
      perms = localPerms;
    } catch (dbErr) {
      console.error('[API /user-permissions] Local profiles/perms query failed:', dbErr.message);
      throw dbErr;
    }

    const mapped = (profiles || []).map(p => {
      const userPerms = (perms || [])
        .filter(up => String(up.user_id) === String(p.id))
        .map(up => ({ section: up.section, has_access: up.has_access }));
      return { ...p, permissions: userPerms };
    });

    console.log(`[API /user-permissions] Sent ${mapped.length} users to frontend.`);
    res.json(mapped);
  } catch (err) {
    console.error('GET /api/user-permissions error:', err.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// GET /api/user-permissions/:user_id — permissions for a specific user
router.get('/:user_id', requireAuth, async (req, res) => {
  try {
    const { user_id } = req.params;
    try {
      const { rows } = await db.query(
        'SELECT section, has_access FROM user_permissions WHERE user_id = $1',
        [user_id]
      );
      return res.json(rows);
    } catch (dbErr) {
      console.error('[API /user-permissions/:user_id] Local query failed:', dbErr.message);
      throw dbErr;
    }
  } catch (err) {
    console.error('GET /api/user-permissions/:user_id error:', err.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// POST /api/user-permissions — upsert a single permission
router.post('/', requireAuth, async (req, res) => {
  try {
    const { user_id, section, has_access } = req.body;
    if (!user_id || !section || typeof has_access !== 'boolean') {
      return res.status(400).json({ error: 'Missing or invalid body parameters' });
    }

    const granted_by = req.user?.sub || null;

    try {
      await db.query(
        `INSERT INTO user_permissions (user_id, section, has_access, granted_by, updated_at) 
         VALUES ($1, $2, $3, $4, NOW()) 
         ON CONFLICT (user_id, section) 
         DO UPDATE SET has_access = EXCLUDED.has_access, granted_by = EXCLUDED.granted_by, updated_at = NOW()`,
        [user_id, section, has_access, granted_by]
      );
    } catch (dbErr) {
      console.error('[API /user-permissions POST] Local upsert failed:', dbErr.message);
      throw dbErr;
    }

    console.log(`[API /user-permissions] Saved: user=${user_id} section="${section}" access=${has_access}`);
    return res.json({ success: true, message: 'Permission updated' });
  } catch (err) {
    console.error('POST /api/user-permissions error:', err.message);
    return res.status(500).json({ success: false, error: err?.message || 'Internal Server Error' });
  }
});

module.exports = router;
